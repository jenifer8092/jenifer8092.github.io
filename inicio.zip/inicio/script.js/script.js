// Seleccionar los elementos del DOM
const email = document.getElementById('email');
const password = document.getElementById('password');
const emailError = document.getElementById('error-email');
const passwordError = document.getElementById('error-password');
const loginButton = document.getElementById('loginButton');

// Validación del formulario
loginButton.addEventListener('click', function() {
    let valid = true;

    // Limpiar mensajes de error
    emailError.style.display = 'none';
    passwordError.style.display = 'none';

    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.value) {
        emailError.innerText = 'Por favor, introduce tu correo electrónico.';
        emailError.style.display = 'block';
        valid = false;
    } else if (!emailRegex.test(email.value)) {
        emailError.innerText = 'Por favor, introduce una dirección de correo electrónico válida.';
        emailError.style.display = 'block';
        valid = false;
    }

    // Validar contraseña
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    if (!password.value) {
        passwordError.innerText = 'Por favor, introduce tu contraseña.';
        passwordError.style.display = 'block';
        valid = false;
    } else if (!passwordRegex.test(password.value)) {
        passwordError.innerText = 'La contraseña debe tener al menos 8 caracteres, incluir una letra mayúscula, una letra minúscula y un número.';
        passwordError.style.display = 'block';
        valid = false;
    }

    // Si el formulario es válido, redirigir
    if (valid) {
        window.location.href = 'https://jenifer8092.github.io';
    }
});
